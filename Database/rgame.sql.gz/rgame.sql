-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 31, 2021 at 04:45 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rgame`
--

-- --------------------------------------------------------

--
-- Table structure for table `game_row`
--

CREATE TABLE `game_row` (
  `id` int(11) NOT NULL,
  `g_name` varchar(200) DEFAULT NULL,
  `g_img` varchar(100) DEFAULT NULL,
  `g_link` text DEFAULT NULL,
  `g_status` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `game_row`
--

INSERT INTO `game_row` (`id`, `g_name`, `g_img`, `g_link`, `g_status`) VALUES
(2, 'TEST 02', '60161fe75384c-1612062695.png', 'https://lionroyal.casino', '0'),
(3, 'TEST 01', '60162154a7651-1612063060.png', 'https://lionroyal.casino', '0'),
(4, 'TEST 03', '6016216628ce7-1612063078.png', 'https://lionroyal.casino', '0'),
(5, 'TEST 04', '60162171b320a-1612063089.png', 'https://lionroyal.casino', '0'),
(6, 'TEST 05', '6016217c90914-1612063100.png', 'https://lionroyal.casino', '0'),
(7, 'TEST 06', '60162187e5ccb-1612063111.png', 'https://lionroyal.casino', '0'),
(8, 'TEST 07', '6016219cc4b6a-1612063132.png', 'https://lionroyal.casino', '0'),
(9, 'TEST 08', '601623772bf75-1612063607.png', 'https://lionroyal.casino', '0');

-- --------------------------------------------------------

--
-- Table structure for table `section1`
--

CREATE TABLE `section1` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_desc` text DEFAULT NULL,
  `g_detail` text DEFAULT NULL,
  `g_video` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section1`
--

INSERT INTO `section1` (`sid`, `g_title`, `g_desc`, `g_detail`, `g_video`, `g_background`) VALUES
(1, 'لايون رويال كازينو', 'قديمى ترين پوكر كلاب ايران', 'همين حالا ثبت نام كنيد و بازى خود وا شروع كنيد', 'https://www.youtube.com/embed/keIt6LJEC44', '601502268d45e-1611989542.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `section2`
--

CREATE TABLE `section2` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_detail` text DEFAULT NULL,
  `g_link` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section2`
--

INSERT INTO `section2` (`sid`, `g_title`, `g_detail`, `g_link`, `g_background`) VALUES
(1, 'آخرين جوايز و تورنمنت ها', '! همین الان بازیتو انتخاب کن !', 'https://lionroyal.casino', '6015112d020bc-1611993389.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `section3`
--

CREATE TABLE `section3` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_name` text DEFAULT NULL,
  `g_name2` text DEFAULT NULL,
  `g_name3` text DEFAULT NULL,
  `g_name4` text DEFAULT NULL,
  `g_img` text DEFAULT NULL,
  `g_img2` text DEFAULT NULL,
  `g_img3` text DEFAULT NULL,
  `g_img4` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section3`
--

INSERT INTO `section3` (`sid`, `g_title`, `g_name`, `g_name2`, `g_name3`, `g_name4`, `g_img`, `g_img2`, `g_img3`, `g_img4`, `g_background`) VALUES
(1, 'روش هاى خريد و برداشت در لايون رويال', 'https://lionroyal.casino', 'https://lionroyal.casino', 'https://lionroyal.casino', 'حمايت از كاربر', '60150cc74fade-1611992263.png', '60150cc74fde1-1611992263.png', '60150cc74ff2f-1611992263.png', NULL, '60150c0d1337b-1611992077.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `section4`
--

CREATE TABLE `section4` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_detail` text DEFAULT NULL,
  `g_img` text DEFAULT NULL,
  `g_link` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section4`
--

INSERT INTO `section4` (`sid`, `g_title`, `g_detail`, `g_img`, `g_link`, `g_background`) VALUES
(1, 'دعوت و پول سازى', 'آروان گیم به عنوان اولین پلتفرم آنلاین برای برگزاری مسابقات ویدیوگیم، بستری مورد اعتماد و سرگرم‌کننده است که تمامی گیمرهای ایرانی از سرتاسر ایران را فرا می‌خواند. هدف ما از ایجاد آروان گیم، فراهم‌سازی یک شبکه اجتماعی بزرگ و صمیمی است تا بتوانیم به نوبه خود سهمی در فرهنگسازی جامعه رو به رشد گیمرهای ایرانی داشته باشیم. آروان گیم برای ایجاد یک جامعه مجازی برای گیمرها در مطلوب‌ترین فرم آن، مشتاقانه از ایده‌های جدید و پیشنهادات خلاقانه شما استقبال می‌کند. شما می‌توانید از طریق بخش ارتباط با ما پیشنهادها و انتقادهای خود را با تیم ما در میان بگذارید. شایان به ذکر است که نقل و انتقالات مالی آروان گیم، در یک بستر کاملا قانونی و امن صورت می‌گیرد. شما می‌توانید اطلاعات تکمیلی در رابطه با این موضوع را در بخش قوانین مطالعه کنید. آروان گیم پیوسته درحال تغییر و تحول است و امکانات بیشتری در آینده به سرویس‌های ما افزوده خواهد شد. از جمله بازی‌های بیشتر و همچنین امکانات کامل‌تر برای ایجاد یک جامعه مجازی ایده‌آل. شما کاربر گرامی، همین حالا می‌توانید با تکمیل کردن پروسه ثبت نام، وارد مسابقات شوید و توجه داشته باشید که آروان گیم برنامه‌های تشویقی بسیاری برای کاربران برتر و فعال خود در نظر گرفته است. در آروان گیم حریف بطلبید!', '601504823a68e-1611990146.png', 'https://lionroyal.casino', '60150e12e4934-1611992594.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `section5`
--

CREATE TABLE `section5` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_name` text DEFAULT NULL,
  `g_name2` text DEFAULT NULL,
  `g_name3` text DEFAULT NULL,
  `g_name4` text DEFAULT NULL,
  `g_img` text DEFAULT NULL,
  `g_img2` text DEFAULT NULL,
  `g_img3` text DEFAULT NULL,
  `g_img4` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section5`
--

INSERT INTO `section5` (`sid`, `g_title`, `g_name`, `g_name2`, `g_name3`, `g_name4`, `g_img`, `g_img2`, `g_img3`, `g_img4`, `g_background`) VALUES
(1, 'ويژگى هاى لايون رويال', 'امنيت بالا', 'دسترسى آسان', 'خريد و برداشت لحظه اى', 'حمايت از كاربر', '6015089ebafbd-1611991198.svg', '601508cc3995c-1611991244.svg', '601508f297760-1611991282.svg', '601508f297870-1611991282.svg', '60150deb5cb93-1611992555.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `section6`
--

CREATE TABLE `section6` (
  `sid` int(11) NOT NULL,
  `g_title` text DEFAULT NULL,
  `g_img` text DEFAULT NULL,
  `g_background` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section6`
--

INSERT INTO `section6` (`sid`, `g_title`, `g_img`, `g_background`) VALUES
(1, 'تاريخ و زمان تورنمنت حرفه اى ها', '601500181b5f8-1611989016.png', '6015026888944-1611989608.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `sid` int(11) NOT NULL,
  `maintenance` varchar(11) DEFAULT NULL,
  `g_logo` varchar(50) DEFAULT NULL,
  `g_title` text DEFAULT NULL,
  `g_description` text DEFAULT NULL,
  `g_keywords` text DEFAULT NULL,
  `g_author` text DEFAULT NULL,
  `social_telegram` text DEFAULT NULL,
  `social_instagram` text DEFAULT NULL,
  `social_youtube` text DEFAULT NULL,
  `g_login` text DEFAULT NULL,
  `g_register` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`sid`, `maintenance`, `g_logo`, `g_title`, `g_description`, `g_keywords`, `g_author`, `social_telegram`, `social_instagram`, `social_youtube`, `g_login`, `g_register`) VALUES
(1, '0', '6014f949c4bb7-1611987273.svg', 'قديمى ترين پوكر كلاب ايران', 'مسابقه آنلاین ویدئو گیم با کامپیوتر، موبایل، پلی استیشن و ایکس باکس. شما در آروان گیم میتوانید مهارت خود در بازی های ویدئویی را تبدیل به یک شغل پولساز کنید کسب درآمد از بازی های اندروید، کسب درآمد از کالاف موبایل.', 'arvangame , r1game ,آروان گیم ,آروان ,pes20, pes21 , fifa20 , fifa21 , Dota2 , dota II , 8ballpool , 8 ball pool , مسابقه , ویدئو گیم , فیفا , پس,فوتبال ,دوتا ,دوتا2 , موبایل , مسابقه کالاف ,مسابقه فیفا , مسابقه آنلاین فیفا , مسابقه آنلاین pes , لیگ آنلاین , لیگ ویدئو گیم, بازی , مسابقه', 'r1 team', 'https://t.me/LionRoyalCasino', 'https://www.instagram.com/LionRoyalSupport/', 'https://youtube.com/channel/UCKtvBYuizapLImTFIOSMeHw', 'https://www.lionroyal.casino', 'https://www.lionroyal.casino');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL,
  `Player` varchar(50) NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Telephone` varchar(50) DEFAULT NULL,
  `permission` varchar(20) DEFAULT NULL,
  `uactive` varchar(1) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `Player`, `Email`, `Telephone`, `permission`, `uactive`, `password`, `datetime`) VALUES
(1, 'adminT-T', 'admin@lionroyal.casino', '0988888888', 'admin', '1', 'd16484z2u22394b4', '2021-01-30 10:12:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game_row`
--
ALTER TABLE `game_row`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section1`
--
ALTER TABLE `section1`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `section2`
--
ALTER TABLE `section2`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `section3`
--
ALTER TABLE `section3`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `section4`
--
ALTER TABLE `section4`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `section5`
--
ALTER TABLE `section5`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `section6`
--
ALTER TABLE `section6`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `game_row`
--
ALTER TABLE `game_row`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `section1`
--
ALTER TABLE `section1`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section2`
--
ALTER TABLE `section2`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section3`
--
ALTER TABLE `section3`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section4`
--
ALTER TABLE `section4`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section5`
--
ALTER TABLE `section5`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section6`
--
ALTER TABLE `section6`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
